@echo off
setlocal
cd /d "%~dp0"
title Authentic Morrowind - Partial Mod Installer
echo ===========================================
echo  AUTHENTIC MORROWIND - PARTIAL INSTALLER
echo ===========================================
echo Configures already extracted mods. Does NOT download them.
echo Previews changes and requires confirmation before applying.
echo Creates backups of openmw.cfg and settings.cfg.
echo Missing mods will be skipped; missing masters can break game startup.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 apply_authentic.py --apply --allow-incomplete %*
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo ERROR: Python 3.9 or newer is required.
        pause
        exit /b 1
    )
    python apply_authentic.py --apply --allow-incomplete %*
)
echo.
echo Review the preview folder and check OpenMW Launcher after applying.
pause
