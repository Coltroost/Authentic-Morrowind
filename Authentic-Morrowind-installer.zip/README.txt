AUTHENTIC MORROWIND - TWO FOLDER CONFIG GENERATOR
=================================================

THIS IS A CONFIG GENERATOR, NOT A FILE COPIER. Your I Heart Vanilla DC
mod files and your custom Authentic Morrowind mod files remain unchanged.
In OpenMW, a later data= path has higher asset override priority. The script
builds each data-path-order entry as IHV DC first, custom Authentic second.
It does not append all custom folders after the list, because that would
break your desired YAML load order. Plugin order follows plugin-order.yml.

REQUIREMENTS: Windows, Python 3.9+, installed OpenMW, existing working
Morrowind/Data Files, both mod folders fully extracted.

1. Extract this ZIP somewhere writable (not Program Files).
2. Double click APPLY_AUTHENTIC.bat.
3. Enter FULL PATHS to:
   - your existing OpenMW openmw.cfg
   - your existing OpenMW settings.cfg (same folder in most installations)
   - I Heart Vanilla Director's Cut mods root folder
   - your custom Authentic Morrowind mods root folder
4. Inspect preview/authentic-report.txt, openmw-authentic-PREVIEW.cfg,
   settings-authentic-PREVIEW.cfg.
5. If you see missing or ambiguous data/plugin entries, fix their folders
   and rerun. The script WILL REFUSE to apply while blockers remain.
6. To apply, open Command Prompt in this folder and run:
      py -3 apply_authentic.py --apply
   Enter the same paths and explicitly type APPLY.
7. Open OpenMW Launcher and inspect the plugin list. Test a NEW SAVE.

You may pass paths as command arguments to avoid retyping:
  py -3 apply_authentic.py --cfg "C:\...\openmw.cfg" --settings "C:\...\settings.cfg" --dc "D:\...\IHeartVanilla" --custom "D:\...\AuthenticMorrowind"

BACKUPS: openmw.cfg.backup-authentic-TIMESTAMP and
         settings.cfg.backup-authentic-TIMESTAMP beside your originals.

IMPORTANT NOTES:
- The script only edits two OpenMW CFG files after --apply + APPLY.
- It does not change mod archives, physically overwrite assets, or download mods.
- If the same plugin occurs in two data folders, OpenMW's later data folder
  takes priority; the report names the selected winner.
- Plugin masters are checked using TES3 plugin headers; .omwscripts are checked
  only for file presence, not Lua API dependencies.
- Missing or ambiguous entries block applying instead of silently skipping.
- BSA registrations from extra-cfg are added only when the archive exists.
- This is stricter than the original BAT, so large incomplete installs may
  need fixes indicated in the report before applying.
- Keep the originally configured Morrowind game folder accessible.

PARTIAL / INCOMPLETE TEST MODE
------------------------------
If you're still downloading mods and want to APPLY THE FOUND SUBSET anyway:
  1. Double-click APPLY_PARTIAL_TEST.bat.
  2. Provide the same paths as before.
  3. Inspect the preview report.
  4. Type exactly: APPLY INCOMPLETE TEST
This overrides only the missing/ambiguous/dependency BLOCKER CHECK; it does
not fabricate missing plugins or alter your physical mod files. Missing plugins
and unresolved folders remain omitted. Because key masters (e.g. Tamriel_Data)
are missing, OpenMW may fail to launch. The existing configs are backed up.

For manual use:
  py -3 apply_authentic.py --apply --allow-incomplete
For normal strict mode, use APPLY_AUTHENTIC.bat and --apply as before.
Restore backups named *.backup-authentic-YYYYMMDD-HHMMSS if needed.

PROVINCE DETECTION FIX (November 2026)
--------------------------------------
- Tamriel Data is located by Tamriel_Data.esm anywhere inside either selected mods root.
- Tamriel Rebuilt core is located by TR_Mainland.esm.
- The OPTIONAL Tamriel Rebuilt Faction Integration is now included in the
  manifest and is located by TR_Factions.esp (often under
  01 Faction Integration\Data Files).
- TR_Factions.esp is enabled immediately after TR_Mainland.esm in the
  generated plugin list, provided the physical plugin file exists.
- If the script reports 'required ... not found', the file is absent from
  BOTH selected mod roots or is inside an archive that was not extracted.
  Check that the IHV DC root selected actually includes these files.
- If you do not want optional faction integration, remove its single entry
  from manifest data_paths and plugins, or leave it absent and use partial
  preview (partial apply will omit it).
- This script does not copy assets; it only writes OpenMW config after
  confirmation and keeps timestamped backups.

V3 ORDER GUARANTEE (Nov 2026)
-----------------------------
This package includes data-path-order.yml and plugin-order.yml. The Python
script verifies the exact bundled YAML files before acting. The generated
openmw.cfg data= lines follow the original YAML entry sequence, including
intentional repeated entries. For a logical YAML entry found in both I Heart
Vanilla DC and custom mods, DC goes first and custom goes second, at that
same position so the custom files override DC. Missing entries are reported
and not invented. No global sorting, no moving repeats to the end.

Tamriel Data: recognized by Tamriel_Data.esm; Tamriel Rebuilt by
TR_Mainland.esm, independent of surrounding folder names. Ambiguities are
reported rather than guessed.

TR_Factions.esp does NOT appear in the ORIGINAL supplied data-path-order.yml
or plugin-order.yml. To preserve EXACTLY your original YAML, the normal BAT
files do not add it. If you want it enabled, choose the explicit optional
command (adds one extra data= folder and one content= plugin after TR Mainland):
  py -3 apply_authentic.py --include-tr-factions
For incomplete apply WITH faction integration:
  py -3 apply_authentic.py --apply --allow-incomplete --include-tr-factions
The preview report shows YAML ORDER PRESERVED and optional setting status.

If you edit the YAML files, this bundle will refuse to apply, since the
bundled manifest must be regenerated to match the edited YAML. This protects
against silently producing a different ordering than requested.
