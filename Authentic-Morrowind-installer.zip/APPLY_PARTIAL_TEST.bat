@echo off
setlocal
cd /d "%~dp0"
echo AUTHENTIC MORROWIND - INCOMPLETE TEST APPLY
echo This will replace live OpenMW configuration AFTER explicit confirmation.
echo It will back up both CFG files, but missing masters may stop the game loading.
echo Press Ctrl+C now if you do not want to continue.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 apply_authentic.py --apply --allow-incomplete %*
) else (
    python apply_authentic.py --apply --allow-incomplete %*
)
echo.
echo Finished. Please inspect the preview and test OpenMW Launcher.
pause
