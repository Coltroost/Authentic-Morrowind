"""Authentic Morrowind two-install config builder. Python 3.9+, stdlib only.

No mod files are ever copied or overwritten. OpenMW VFS uses later data= entries
for asset overrides. Preview is default. APPLY requires interactive confirmation.
"""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys

HERE = Path(__file__).resolve().parent
SOURCE_SHA256 = {'data-path-order.yml': '91c33c000e5cc8f8670c586c8de5c170e048588996f10da48910a4d190698677', 'plugin-order.yml': '5519fa17e02bce16a7f0e5d97c761b5c172d6bbd73e20d8e71f62a6134d35c53'}
MAN = json.loads((HERE / 'authentic_order_manifest.json').read_text(encoding='utf-8'))
EXTRA = json.loads((HERE / 'extra_settings.json').read_text(encoding='utf-8'))
PLUG_EXT = {'.esp', '.esm', '.omwaddon', '.omwscripts'}
ASSET_DIRS = {'meshes','textures','icons','sound','music','shaders','scripts','resources',
              'fonts','splash','video','bookart','interface','mw-lua','groundcover',
              'animation','animations','vfx','materials'}
ASSET_EXTS = {'.dds','.tga','.nif','.kf','.wav','.mp3','.ogg','.png','.jpg',
              '.lua','.omwfx','.bsa','.ttf','.otf'}
NORM = lambda x: re.sub(r'[^a-z0-9]', '', str(x).lower())

def ask(label, default=''):
    value = input(f'{label}' + (f' [{default}]' if default else '') + ': ').strip().strip('"').strip("'")
    return value or default

def canonical(p): return str(Path(p).resolve()).casefold()

def datafiles(directory):
    try: return [x for x in directory.iterdir() if x.is_file()]
    except (OSError, PermissionError): return []

def valid_data(p):
    try:
        entries = list(p.iterdir())
        return any(x.is_file() and (x.suffix.casefold() in PLUG_EXT | ASSET_EXTS) for x in entries) or any(x.is_dir() and x.name.casefold() in ASSET_DIRS for x in entries)
    except (OSError, PermissionError): return False

def beneath(path, root):
    try: path.relative_to(root); return True
    except ValueError: return False

def unique(items):
    d = {}
    for x in items: d.setdefault(canonical(x), x)
    return list(d.values())

def modnames():
    lookup = collections.defaultdict(set)
    for a in MAN['archives']:
        mod = a['for_mod']
        value = a.get('extract_to', '').replace('\\','/').split('/')[0]
        if value: lookup[mod].add(NORM(value))
    for item in MAN['data_paths']:
        mod = item['for_mod']
        lookup[mod].add(NORM(mod))
    return lookup

def scan(root):
    folders = []
    by_name = collections.defaultdict(list)
    by_plugin = collections.defaultdict(list)
    for at, sub, fs in os.walk(root):
        sub[:] = [s for s in sub if s.casefold() not in ('.git','__pycache__','.cache')]
        d = Path(at)
        folders.append(d)
        by_name[NORM(d.name)].append(d)
        for filename in fs:
            if Path(filename).suffix.casefold() in PLUG_EXT:
                by_plugin[filename.casefold()].append(d / filename)
    return {'root':root, 'folders':folders,'by_name':by_name,'plugins':by_plugin}

def roots_for(mod, scan_result, aliases):
    candidates = unique(p for alias in aliases[mod] for p in scan_result['by_name'].get(alias, []))
    if not candidates: return []
    depth = min(len(x.relative_to(scan_result['root']).parts) for x in candidates)
    return [p for p in candidates if len(p.relative_to(scan_result['root']).parts) == depth]

PROVINCE_FILES = {
    'Tamriel Data': 'tamriel_data.esm',
    'Tamriel Rebuilt': 'tr_mainland.esm',
}

def province_by_plugin(entry, scanned):
    """Locate the actual game-data directory, regardless of extracted wrappers.

    The official archives may be nested under 00 Data Files / 00 Core /
    01 Faction Integration / Data Files, or under a different root in IHV DC.
    """
    mod = entry['for_mod']
    filename = PROVINCE_FILES[mod]
    hits = unique(p.parent for p in scanned['plugins'].get(filename, [])
                  if valid_data(p.parent))
    if len(hits) == 1:
        return hits, None
    if len(hits) > 1:
        return [], 'ambiguous '+filename+' found in: ' + ' | '.join(map(str,hits))
    return [], ('required '+filename+' not found anywhere under '+str(scanned['root'])
                +'; verify archive was extracted, not just downloaded')

def select(entry, scanned, aliases, wanted_plugins):
    mod = entry['for_mod']
    # These two mods have unique content filenames. Prefer exact file-based
    # detection over fragile mod/archive folder names, even if an alias matches.
    if mod in PROVINCE_FILES:
        return province_by_plugin(entry, scanned)
    parents = roots_for(mod, scanned, aliases)
    if not parents: return [], 'root not found'
    if len(parents)>1: return [], 'ambiguous mod root: '+ ' | '.join(map(str,parents))
    parent = parents[0]
    extras = entry.get('extra_dirs') or []
    if extras:
        found = []
        for extra in extras:
            segments = tuple(NORM(x) for x in re.split(r'[\\/]+', extra) if x)
            matches=[]
            for d in scanned['folders']:
                if not beneath(d,parent): continue
                rel=tuple(NORM(x) for x in d.relative_to(parent).parts)
                if segments and len(rel)>=len(segments) and rel[-len(segments):]==segments and valid_data(d):
                    matches.append(d)
            if len(matches)!=1:
                return [], ('no directory for '+extra if not matches else 'ambiguous directory for '+extra+': '+' | '.join(map(str,matches)))
            found.extend(matches)
        return unique(found), None
    # With no explicit path, first identify the folders containing this mod's requested plugins.
    plugin_dirs=[]
    for name in wanted_plugins.get(mod, []):
        for hit in scanned['plugins'].get(name, []):
            if beneath(hit,parent): plugin_dirs.append(hit.parent)
    plugin_dirs = unique(plugin_dirs)
    if plugin_dirs:
        # Multiple plugin-bearing directories can be valid; refuse duplicate variants.
        for name in wanted_plugins.get(mod, []):
            hits=unique(x.parent for x in scanned['plugins'].get(name,[]) if beneath(x,parent))
            if len(hits)>1: return [], 'ambiguous plugin variant: '+name
        return plugin_dirs, None
    # Asset-only: accept a unique leaf data root, not arbitrary packaging wrappers.
    ddirs = [x for x in scanned['folders'] if beneath(x,parent) and valid_data(x)]
    leaves = [x for x in ddirs if not any(x!=y and beneath(y,x) for y in ddirs)]
    leaves = unique(leaves)
    if len(leaves)==1: return leaves, None
    return [], 'no data directory' if not leaves else 'ambiguous asset data dirs: '+' | '.join(map(str,leaves))

def read_lines(p): return p.read_text(encoding='utf-8-sig',errors='replace').splitlines()

def render_cfg(original, directories, contents, fallback):
    keep = [x for x in original if not re.match(r'^\s*(?:data|content)\s*=',x,re.I)]
    # Rebuild fallback archives only when there is an additional, verified archive.
    known={m.group(1).strip().casefold() for x in keep if (m:=re.match(r'^\s*fallback-archive\s*=\s*(.+?)\s*$',x,re.I))}
    for archive in fallback:
        if archive.casefold() not in known:
            keep.append('fallback-archive='+archive)
            known.add(archive.casefold())
    return '\n'.join(keep+[f'data="{str(d)}"' for d in directories]+[f'content={n}' for n in contents])+'\n'

def render_settings(old, entries):
    """Merge OpenMW settings by section/key while preserving unrelated settings."""
    lines=list(old)
    # Last requested value for a duplicate key wins, exactly like other settings.
    merged=collections.OrderedDict()
    for section,key,value in entries:
        merged[(section.casefold(),key.casefold())]=(section,key,value)
    for sec,key,value in merged.values():
        sections=[]
        for i,line in enumerate(lines):
            match=re.match(r'^\s*\[([^\]]+)\]\s*$',line)
            if match: sections.append((i,match.group(1)))
        found=next((j for j,(i,name) in enumerate(sections) if name.casefold()==sec.casefold()),None)
        if found is None:
            if lines and lines[-1].strip(): lines.append('')
            lines.extend([f'[{sec}]',f'{key} = {value}'])
            continue
        start=sections[found][0]
        end=sections[found+1][0] if found+1<len(sections) else len(lines)
        hits=[]
        for i in range(start+1,end):
            match=re.match(r'^\s*([^#;=]+?)\s*=\s*.*$',lines[i])
            if match and match.group(1).strip().casefold()==key.casefold(): hits.append(i)
        if hits:
            lines[hits[0]]=f'{key} = {value}'
            for i in reversed(hits[1:]): lines.pop(i)
        else: lines.insert(end,f'{key} = {value}')
    return '\n'.join(lines).rstrip()+'\n'

def master_names(plugin):
    """Read the header of a TES3 ESM/ESP/OMWADDON without third-party packages."""
    if plugin.suffix.casefold()=='.omwscripts': return []
    try:
        with plugin.open('rb') as f:
            header=f.read(16)
            if len(header)<16 or header[:4]!=b'TES3': return None
            size=int.from_bytes(header[4:8],'little')
            if size>16*1024*1024: return None
            block=f.read(size)
        names=[]; pos=0
        while pos+8<=len(block):
            name=block[pos:pos+4]; length=int.from_bytes(block[pos+4:pos+8],'little');pos+=8
            if length>len(block)-pos: break
            if name==b'MAST': names.append(block[pos:pos+length].split(b'\0')[0].decode('cp1252',errors='replace'))
            pos+=length
        return names
    except (OSError,PermissionError): return None

def main():
    parser=argparse.ArgumentParser(description='Combine DC and custom mods by Authentic Morrowind data-path/plugin order')
    parser.add_argument('--dc',help='I Heart Vanilla Director\'s Cut mod folder')
    parser.add_argument('--custom',help='Authentic Morrowind mod folder')
    parser.add_argument('--cfg',help='OpenMW openmw.cfg')
    parser.add_argument('--settings',help='OpenMW settings.cfg')
    parser.add_argument('--include-tr-factions',action='store_true',help='Opt in to adding TR_Factions.esp and its folder immediately after TR Mainland (extra to YAML)')
    parser.add_argument('--apply',action='store_true',help='Request applying; still prompts for APPLY')
    parser.add_argument('--allow-incomplete',action='store_true',help='Allow a TEST apply despite missing/ambiguous mods or masters; requires --apply and explicit confirmation')
    args=parser.parse_args()
    print('AUTHENTIC MORROWIND: DC FOUNDATION + CUSTOM OVERRIDES')
    # Fail closed if the bundled YAML is no longer identical to the source manifest.
    for fname, field in [('data-path-order.yml','data_paths'),('plugin-order.yml','plugins')]:
        expected=SOURCE_SHA256[fname]
        source=HERE/fname
        if not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest()!=expected:
            sys.exit('ERROR: '+fname+' differs from bundled source. Rebuild the manifest before applying. No changes made.')
    print('Preview is default. No mod files will be modified.')
    home=Path.home()
    cfg=Path(args.cfg or ask('Full path to openmw.cfg',str(home/'Documents'/'My Games'/'OpenMW'/'openmw.cfg'))).expanduser().resolve()
    if not cfg.is_file(): sys.exit('ERROR: openmw.cfg not found. No changes made.')
    settings=Path(args.settings or ask('Full path to settings.cfg',str(cfg.with_name('settings.cfg')))).expanduser().resolve()
    if not settings.is_file(): sys.exit('ERROR: settings.cfg not found. No changes made.')
    dc=Path(args.dc or ask('I Heart Vanilla DC mods folder')).expanduser().resolve()
    custom=Path(args.custom or ask('Authentic Morrowind CUSTOM mods folder')).expanduser().resolve()
    if not dc.is_dir() or not custom.is_dir() or canonical(dc)==canonical(custom):
        sys.exit('ERROR: supply two separate, existing mod directories. No changes made.')
    cfg_lines=read_lines(cfg); settings_lines=read_lines(settings)
    existing=[]
    for line in cfg_lines:
        m=re.match(r'^\s*data\s*=\s*(.*?)\s*$',line,re.I)
        if m:
            p=Path(os.path.expandvars(m.group(1).strip().strip('"')))
            if p.is_dir(): existing.append(p.resolve())
    game=next((p for p in existing if any(f.name.casefold()=='morrowind.esm' for f in datafiles(p))),None)
    if not game:
        game=Path(ask('Morrowind original Data Files folder')).expanduser().resolve()
    if not any(f.name.casefold()=='morrowind.esm' for f in datafiles(game)):
        sys.exit('ERROR: original Morrowind.esm not found. No changes made.')
    print('Scanning Director\'s Cut mods ...')
    base=scan(dc)
    print('Scanning custom mods ...')
    overlay=scan(custom)
    aliases=modnames(); wanted=collections.defaultdict(list)
    for p in MAN['plugins']: wanted[p['for_mod']].append(p['file_name'].casefold())
    selected=[]; missed=[]; ambiguous=[]; overrides=[]; active_mods=set()
    cache={}
    for idx,entry in enumerate(MAN['data_paths']):
        mod=entry['for_mod']
        if mod=='Morrowind':
            selected.append((idx,'game',entry,game)); active_mods.add(mod); continue
        # Each logical manifest entry: DC first, then custom. Custom overrides DC.
        found={}; errors={}
        for label,source in [('dc',base),('custom',overlay)]:
            key=(label,mod,tuple(entry.get('extra_dirs') or []))
            if key not in cache: cache[key]=select(entry,source,aliases,wanted)
            dirs,err=cache[key]
            if dirs: found[label]=dirs
            elif err: errors[label]=err
        if not found:
            reason='; '.join(f'{k}: {v}' for k,v in errors.items())
            if 'ambiguous' in reason: ambiguous.append((idx,mod,entry.get('extra_dirs'),reason))
            else: missed.append((idx,mod,entry.get('extra_dirs'),reason))
            continue
        active_mods.add(mod)
        for label in ('dc','custom'):
            for p in found.get(label,[]): selected.append((idx,label,entry,p))
        if 'dc' in found and 'custom' in found:
            overrides.append((mod,entry.get('extra_dirs'),found['dc'],found['custom']))
    # Preserve YAML order EXACTLY, including repeated entries. Do not move a
    # directory to its last appearance: that changes the user's desired order.
    final=list(selected)
    optional_faction=[]
    if args.include_tr_factions:
        for label,source in [('dc',base),('custom',overlay)]:
            matches=unique(hit.parent for hit in source['plugins'].get('tr_factions.esp',[]) if valid_data(hit.parent))
            if len(matches)>1:
                ambiguous.append((-1,'TR Faction Integration',None,label+': multiple TR_Factions.esp folders: '+' | '.join(map(str,matches))))
            elif matches: optional_faction.append((label,matches[0]))
        if optional_faction:
            # Insert immediately after the last Tamriel Rebuilt occurrence.
            at=next((i+1 for i,(_,_,e,_) in reversed(list(enumerate(final))) if e['for_mod']=='Tamriel Rebuilt'),None)
            if at is not None:
                for label,folder in optional_faction:
                    final.insert(at,(-1,label,{'for_mod':'TR Faction Integration (optional)'},folder))
                    at+=1
    # All regular entries remain in the same sequence as the supplied YAML.
    original_indices=[idx for idx,_,_,_ in final if idx>=0]
    if original_indices!=sorted(original_indices):
        sys.exit('INTERNAL ERROR: data-path order was changed; no changes made.')
    dirs=[x[3] for x in final]
    byfilename=collections.defaultdict(list)
    for order,(_,label,entry,folder) in enumerate(final):
        for p in datafiles(folder):
            if p.suffix.casefold() in PLUG_EXT:
                byfilename[p.name.casefold()].append((order,p,label))
    content=[]; missing_plugins=[]; plugin_sources={}; duplicates=[]
    for item in MAN['plugins']:
        name=item['file_name']; hits=byfilename.get(name.casefold(),[])
        if not hits:
            missing_plugins.append((item['for_mod'],name)); continue
        # Later active data path wins exactly as OpenMW's VFS resolves the filename.
        chosen=hits[-1]
        if name.casefold() not in {x.casefold() for x in content}:
            content.append(name)
            plugin_sources[name.casefold()]=chosen[1]
        if len(hits)>1: duplicates.append((name,hits))
    # Optional plugin is never inserted unless the user explicitly requests it.
    if args.include_tr_factions and optional_faction:
        faction_hits=byfilename.get('tr_factions.esp',[])
        if faction_hits and not any(x.casefold()=='tr_factions.esp' for x in content):
            at=next((i+1 for i,n in enumerate(content) if n.casefold()=='tr_mainland.esm'),len(content))
            content.insert(at,'TR_Factions.esp')
            plugin_sources['tr_factions.esp']=faction_hits[-1][1]
    # Master checking: engines load content in manifest order.
    index={x.casefold():i for i,x in enumerate(content)}
    missing_masters=[]; wrong_order=[]; unreadable=[]
    for pos,name in enumerate(content):
        p=plugin_sources[name.casefold()]; masters=master_names(p)
        if masters is None:
            unreadable.append((name,str(p))); continue
        for master in masters:
            masterpos=index.get(master.casefold())
            if masterpos is None: missing_masters.append((name,master))
            elif masterpos>=pos: wrong_order.append((name,master))
    fallback=[]; settings_to_apply=[]; warnings=[]
    seen_cfg_archives={m.group(1).strip().casefold() for line in cfg_lines if (m:=re.match(r'^\s*fallback-archive\s*=\s*(.+?)\s*$',line,re.I))}
    accessible_archives={x.name.casefold() for d in dirs for x in datafiles(d) if x.suffix.casefold()=='.bsa'}
    for e in EXTRA:
        if any(m not in active_mods for m in e.get('for_mods',[])): continue
        if e.get('in_settings'):
            section=None
            for raw in e['text'].splitlines():
                line=raw.strip()
                if not line or line.startswith(('#',';')):continue
                if line.startswith('[') and line.endswith(']'):
                    section=line[1:-1].strip();continue
                if '=' in line and section:
                    key,val=line.split('=',1)
                    settings_to_apply.append((section,key.strip(),val.strip()))
        else:
            for line in e['text'].splitlines():
                m=re.match(r'^\s*fallback-archive\s*=\s*(.+?)\s*$',line,re.I)
                if m:
                    archive=m.group(1).strip()
                    if archive.casefold() in accessible_archives: fallback.append(archive)
                    elif archive.casefold() not in seen_cfg_archives:
                        warnings.append('Referenced BSA not found in active data paths: '+archive)
    output_cfg=render_cfg(cfg_lines,dirs,content,fallback)
    output_settings=render_settings(settings_lines,settings_to_apply)
    report=[
        'AUTHENTIC MORROWIND PREVIEW REPORT','='*75,
        'DC root: '+str(dc),'Custom root: '+str(custom),'Game folder: '+str(game),
        'OpenMW config: '+str(cfg),'OpenMW settings: '+str(settings),
        f'Active data entries (including intentional repeats and DC/custom overlays): {len(dirs)} / {len(MAN["data_paths"])} desired YAML entries',
        'YAML ORDER: PRESERVED (optional TR Faction Integration: '+('ON' if args.include_tr_factions else 'OFF')+')',
        f'Enabled plugins: {len(content)} / {len(MAN["plugins"])} desired entries',
        f'Missing data entries: {len(missed)}',f'Ambiguous data entries: {len(ambiguous)}',
        f'Missing plugins: {len(missing_plugins)}',f'Missing plugin masters: {len(missing_masters)}',
        f'Invalid master order: {len(wrong_order)}',f'Unreadable plugin headers: {len(unreadable)}',
        f'Plugins present in more than one active data directory (last takes precedence): {len(duplicates)}',
        f'Logical entries with both DC and custom versions (custom comes second): {len(overrides)}',
        '', 'MISSING DATA ENTRIES:']
    report += [f'{i+1}: {m} / {ex or "<root>"} :: {why}' for i,m,ex,why in missed]
    report += ['','AMBIGUOUS DATA ENTRIES:']+[f'{i+1}: {m} / {ex or "<root>"} :: {why}' for i,m,ex,why in ambiguous]
    report += ['','MISSING PLUGINS:']+[f'{mod}: {p}' for mod,p in missing_plugins]
    report += ['','MISSING MASTERS:']+[f'{p} REQUIRES {m}' for p,m in missing_masters]
    report += ['','INVALID MASTER ORDER:']+[f'{p} MUST FOLLOW {m}' for p,m in wrong_order]
    report += ['','UNREADABLE HEADERS:']+[f'{p}: {f}' for p,f in unreadable]
    report += ['','DUPLICATE PLUGINS (winning file is last):']
    report += [f'{name}: '+' | '.join(f'[{label}] {p}' for _,p,label in hits)+' -> WINNER '+str(hits[-1][1]) for name,hits in duplicates]
    report += ['','BOTH DC AND CUSTOM AVAILABLE:']
    report += [f'{m} / {ex or "<root>"}: DC {";".join(map(str,b))} -> CUSTOM {";".join(map(str,c))}' for m,ex,b,c in overrides]
    if not args.include_tr_factions:
        warnings.append('TR_Factions.esp is NOT in plugin-order.yml or data-path-order.yml. For optional integration use --include-tr-factions (adds an extra entry after TR Mainland).')
    elif not optional_faction:
        warnings.append('Optional TR_Factions.esp requested but was not found in either mod root.')
    report += ['','WARNINGS:']+warnings
    report += ['','FINAL DATA PATH ORDER (last overrides earlier):']+[f'{i+1:03d}. [{label}] {folder}  ({entry["for_mod"]})' for i,(_,label,entry,folder) in enumerate(final)]
    report += ['','FINAL PLUGIN LOAD ORDER:']+[f'{i+1:03d}. {name}  <- {plugin_sources[name.casefold()]}' for i,name in enumerate(content)]
    outdir=HERE/'preview';outdir.mkdir(exist_ok=True)
    (outdir/'openmw-authentic-PREVIEW.cfg').write_text(output_cfg,encoding='utf-8')
    (outdir/'settings-authentic-PREVIEW.cfg').write_text(output_settings,encoding='utf-8')
    (outdir/'authentic-report.txt').write_text('\n'.join(report)+'\n',encoding='utf-8')
    print('\n'.join(report[0:16]))
    print('\nPreview output folder:',outdir)
    blockers=len(missed)+len(ambiguous)+len(missing_plugins)+len(missing_masters)+len(wrong_order)+len(unreadable)
    if blockers and not (args.apply and args.allow_incomplete):
        print(f'BLOCKED: {blockers} issues. Nothing applied. Inspect authentic-report.txt.')
        print('For a deliberate partial-install TEST, run APPLY_PARTIAL_TEST.bat.')
        return 2
    if not args.apply:
        print('PREVIEW ONLY. Re-run with --apply after reviewing the report.')
        return 0
    if blockers:
        print('\n'+'!'*72)
        print('INCOMPLETE TEST MODE: This is NOT a playable or valid mod configuration.')
        print(f'{blockers} unresolved issues; missing masters may prevent startup.')
        print('Only the found portion of your YAML lists will be installed into OpenMW CFG.')
        print('Your current active OpenMW config will be replaced; backups are made.')
        print('!'*72)
        confirmation='APPLY INCOMPLETE TEST'
    else:
        print('No missing entries, masters or ambiguous paths detected.')
        confirmation='APPLY'
    if ask(f'Type {confirmation} to replace your OpenMW configuration (not mod files)')!=confirmation:
        print('Cancelled; original configs untouched.');return 0
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    targets=((cfg,output_cfg),(settings,output_settings))
    backups=[]
    try:
        for dest,_ in targets:
            backup=dest.with_name(dest.name+'.backup-authentic-'+stamp)
            shutil.copy2(dest,backup)
            backups.append((dest,backup))
        for dest,body in targets:
            tmp=dest.with_name(dest.name+'.tmp-authentic')
            try:
                tmp.write_text(body,encoding='utf-8')
                os.replace(tmp,dest)
            finally:
                if tmp.exists(): tmp.unlink()
        for dest,backup in backups: print('Updated',dest,'Backup',backup)
    except Exception:
        for dest,backup in backups:
            try: shutil.copy2(backup,dest)
            except OSError: print('URGENT: Could not restore',dest,'from',backup)
        raise
    print('Finished. Run OpenMW Launcher and validate load order before playing.')
    return 0

if __name__=='__main__':
    try: sys.exit(main())
    except (KeyboardInterrupt,EOFError): sys.exit('\nCancelled; no changes applied unless explicitly confirmed.')
    except Exception as exc: sys.exit('ERROR: '+repr(exc))
