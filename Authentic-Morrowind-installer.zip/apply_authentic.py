"""Authentic Morrowind two-install config builder. Python 3.9+, stdlib only.

Mod folders are never modified. Optional Rafael shader files are copied to the
OpenMW installation only after APPLY confirmation, with backups for conflicts.
"""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys

HERE = Path(__file__).resolve().parent
SOURCE_SHA256 = {'data-path-order.yml': '91c33c000e5cc8f8670c586c8de5c170e048588996f10da48910a4d190698677', 'plugin-order.yml': '5519fa17e02bce16a7f0e5d97c761b5c172d6bbd73e20d8e71f62a6134d35c53'}
MAN = json.loads((HERE / 'authentic_order_manifest.json').read_text(encoding='utf-8'))
EXTRA = json.loads((HERE / 'extra_settings.json').read_text(encoding='utf-8'))
PLUG_EXT = {'.esp', '.esm', '.omwaddon', '.omwscripts'}
SELECTIONS = json.loads((HERE / 'preferred_mod_folders.json').read_text(encoding='utf-8')) if (HERE / 'preferred_mod_folders.json').exists() else {}
AUTO_BY_PLUGIN = set(json.loads((HERE / 'auto_detect_plugins.json').read_text(encoding='utf-8'))) if (HERE / 'auto_detect_plugins.json').exists() else set()
EXCLUDE_PLUGINS = {x.casefold() for x in json.loads((HERE / 'exclude_manifest_plugins.json').read_text(encoding='utf-8'))} if (HERE / 'exclude_manifest_plugins.json').exists() else set()
ASSET_DIRS = {'meshes','textures','icons','sound','music','shaders','scripts','resources',
              'fonts','splash','video','bookart','interface','mw-lua','groundcover',
              'animation','animations','vfx','materials'}
ASSET_EXTS = {'.dds','.tga','.nif','.kf','.wav','.mp3','.ogg','.png','.jpg',
              '.lua','.omwfx','.bsa','.ttf','.otf'}
NORM = lambda x: re.sub(r'[^a-z0-9]', '', str(x).lower())


# User-confirmed paths are relative to the `umo` extraction root. Never rely
# on ambiguous archive names for these installed option folders.
LOCAL = json.loads((HERE / 'local_mod_overrides.json').read_text(encoding='utf-8')) if (HERE / 'local_mod_overrides.json').exists() else {}
PLUGIN_RENAMES = {k.casefold():v for k,v in LOCAL.get('manifest_filename_overrides', {}).items()}

def actual_name(name):
    return PLUGIN_RENAMES.get(name.casefold(), name)

def located_file(scanned, suffix):
    # Lookup by suffix of the *entire* installed relative path, so one can pass
    # custom root as `umo` or its parent. Require a unique exact match.
    parts=tuple(NORM(t) for t in Path(suffix.replace('\\','/')).parts)
    matches=[]
    for name,paths in scanned['plugins'].items():
        for path in paths:
            rel=tuple(NORM(t) for t in path.relative_to(scanned['root']).parts)
            if len(rel)>=len(parts) and rel[-len(parts):]==parts:
                matches.append(path)
    return unique(matches)

def exact_mod_folders(mod, scanned):
    entries=LOCAL.get('mod_files', {}).get(mod)
    if entries is None:return None
    folders=[]
    for suffix in entries:
        matches=located_file(scanned,suffix)
        if len(matches)!=1:
            return [], ('exact path missing: ' if not matches else 'ambiguous exact path: ')+suffix
        folders.append(matches[0].parent)
    return unique(folders), None

def asset_mod_folders(mod,scanned):
    suffixes=LOCAL.get('asset_folders', {}).get(mod)
    if suffixes is None:return None
    result=[]
    for suffix in suffixes:
        parts=tuple(NORM(t) for t in Path(suffix.replace('\\','/')).parts)
        hits=[d for d in scanned['folders'] if len(d.relative_to(scanned['root']).parts)>=len(parts) and tuple(NORM(t) for t in d.relative_to(scanned['root']).parts[-len(parts):])==parts]
        if len(hits)!=1:return [], ('asset folder missing: ' if not hits else 'ambiguous asset folder: ')+suffix
        folder=hits[0]
        # OpenMW needs the parent of textures/, not textures/ itself.
        if folder.name.casefold() in ASSET_DIRS:folder=folder.parent
        if not valid_data(folder):return [], 'not a valid OpenMW data root: '+str(folder)
        result.append(folder)
    return unique(result),None

def explicit_data_folders(mod, scanned):
    """Resolve explicit OpenMW data= roots, even for asset-only shader packs.

    These paths must exist as directories. We deliberately do not require an
    ESP or a standard textures/meshes subfolder in the selected root.
    """
    suffixes = LOCAL.get('data_folders', {}).get(mod)
    if suffixes is None:
        return None
    result = []
    for suffix in suffixes:
        parts = tuple(NORM(t) for t in Path(suffix.replace('\\', '/')).parts)
        hits = [d for d in scanned['folders']
                if len(d.relative_to(scanned['root']).parts) >= len(parts)
                and tuple(NORM(t) for t in d.relative_to(scanned['root']).parts[-len(parts):]) == parts]
        if len(hits) != 1:
            return [], ('data folder missing: ' if not hits else 'ambiguous data folder: ') + suffix
        result.append(hits[0])
    return unique(result), None

def shader_plan(scanned):
    info=LOCAL.get('rafael_shaders',{})
    suffix=info.get('source','')
    if not suffix:return None, None, 'shader source not configured'
    parts=tuple(NORM(t) for t in Path(suffix.replace('\\','/')).parts)
    matches=[d for d in scanned['folders'] if len(d.relative_to(scanned['root']).parts)>=len(parts) and tuple(NORM(t) for t in d.relative_to(scanned['root']).parts[-len(parts):])==parts]
    if len(matches)!=1:return None,None,'shader folder missing or ambiguous: '+suffix
    src=matches[0]
    files=[f for f in src.rglob('*') if f.is_file()]
    if not files:return None,None,'shader folder contains no files: '+str(src)
    configured = Path(info.get('destination', ''))
    # Existing local destination is convenient; on a different PC request its path.
    if configured.is_dir():
        destination = configured
    else:
        path = ask('Rafael shaders destination folder (OpenMW installation\\resources\\shaders; leave blank to SKIP)')
        if not path:
            return None, None, 'shader copy skipped: destination not supplied'
        destination = Path(path).expanduser().resolve()
        if destination.name.casefold() != 'shaders' or destination.parent.name.casefold() != 'resources':
            return None, None, 'shader copy skipped: destination must be resources\\shaders'
        if not destination.parent.is_dir():
            return None, None, 'shader copy skipped: parent resources folder not found: '+str(destination.parent)
    return src,destination,None

def install_shaders(source,destination):
    files=sorted(f for f in source.rglob('*') if f.is_file())
    # Never copy onto the source tree or into it.
    if canonical(source)==canonical(destination) or beneath(destination,source):
        raise RuntimeError('Shader source and destination overlap')
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    backup=HERE/'shader-backups'/stamp
    originals=[(f,destination/f.relative_to(source)) for f in files]
    conflicts=[(f,d) for f,d in originals if d.exists()]
    for f,d in conflicts:
        if not d.is_file():raise RuntimeError('Cannot overwrite shader directory: '+str(d))
    if conflicts:
        for _,d in conflicts:
            back=backup/d.relative_to(destination)
            back.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(d,back)
    copied=[]
    try:
        for src,dst in originals:
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dst)
            copied.append(dst)
    except Exception:
        # Restore originals and remove newly-created files.
        old={d for _,d in conflicts}
        for dst in reversed(copied):
            if dst in old:
                shutil.copy2(backup/dst.relative_to(destination),dst)
            else:
                dst.unlink(missing_ok=True)
        raise
    print(f'Rafael shaders copied: {len(files)} file(s) to {destination}')
    if conflicts:print(f'Original overwritten shaders backed up to: {backup}')

def ask(label, default=''):
    value = input(f'{label}' + (f' [{default}]' if default else '') + ': ').strip().strip('"').strip("'")
    return value or default

def canonical(p): return str(Path(p).resolve()).casefold()

def datafiles(directory):
    try: return [x for x in directory.iterdir() if x.is_file()]
    except (OSError, PermissionError): return []

def valid_data(p):
    try:
        entries = list(p.iterdir())
        return any(x.is_file() and (x.suffix.casefold() in PLUG_EXT | ASSET_EXTS) for x in entries) or any(x.is_dir() and x.name.casefold() in ASSET_DIRS for x in entries)
    except (OSError, PermissionError): return False

def beneath(path, root):
    try: path.relative_to(root); return True
    except ValueError: return False

def unique(items):
    d = {}
    for x in items: d.setdefault(canonical(x), x)
    return list(d.values())

def modnames():
    lookup = collections.defaultdict(set)
    for a in MAN['archives']:
        mod = a['for_mod']
        value = a.get('extract_to', '').replace('\\','/').split('/')[0]
        if value: lookup[mod].add(NORM(value))
        if a.get('name'): lookup[mod].add(NORM(a['name']))
    for item in MAN['data_paths']:
        mod = item['for_mod']
        lookup[mod].add(NORM(mod))
    return lookup

def scan(root):
    folders = []
    by_name = collections.defaultdict(list)
    by_plugin = collections.defaultdict(list)
    for at, sub, fs in os.walk(root):
        sub[:] = [s for s in sub if s.casefold() not in ('.git','__pycache__','.cache')]
        d = Path(at)
        folders.append(d)
        by_name[NORM(d.name)].append(d)
        for filename in fs:
            if Path(filename).suffix.casefold() in PLUG_EXT:
                by_plugin[filename.casefold()].append(d / filename)
    return {'root':root, 'folders':folders,'by_name':by_name,'plugins':by_plugin}

def roots_for(mod, scan_result, aliases, nexus_ids):
    """Match exact archive roots, Nexus-suffixed folders, and verified Nexus IDs.

    Never use unconstrained substring matches: they confuse similarly named mods.
    The caller resolves separate file variants and refuses ambiguous duplicates.
    """
    names = aliases[mod]
    hits = []
    for folder in scan_result['folders']:
        n = NORM(folder.name)
        if not n: continue
        if n in names:
            hits.append((0, folder)); continue
        # A Nexus download folder frequently adds '-12345-1-0-...' to its title.
        # Only accept a prefix if the remainder looks like an archive version/id.
        for alias in names:
            if len(alias) >= 7 and n.startswith(alias):
                suffix = n[len(alias):]
                if suffix and suffix[0].isdigit():
                    hits.append((1,folder)); break
        else:
            ids = nexus_ids.get(mod,set())
            # Full numeric token only, bounded by separators; not timestamps.
            if ids and any(re.search(r'(?:^|[-_ ])'+re.escape(i)+r'(?:[-_ .]|$)', folder.name, re.I) for i in ids):
                hits.append((2,folder))
    if not hits: return []
    # Exact matches are preferable when both a wrapper and its child are present.
    best=min(rank for rank,_ in hits)
    candidates=unique(p for rank,p in hits if rank==best)
    return [p for p in candidates if not any(p!=q and beneath(p,q) for q in candidates)]

def nexus_lookup():
    """Optional compact Nexus metadata, derived from supplied JSON, no internet."""
    path=HERE/'nexus-aliases.json'
    if not path.exists(): return {}
    data=json.loads(path.read_text(encoding='utf-8'))
    return {mod:set(map(str,ids)) for mod,ids in data.items()}

PROVINCE_FILES = {
    'Tamriel Data': 'tamriel_data.esm',
    'Tamriel Rebuilt': 'tr_mainland.esm',
}

def province_by_plugin(entry, scanned):
    """Locate the actual game-data directory, regardless of extracted wrappers.

    The official archives may be nested under 00 Data Files / 00 Core /
    01 Faction Integration / Data Files, or under a different root in IHV DC.
    """
    mod = entry['for_mod']
    filename = PROVINCE_FILES[mod]
    hits = unique(p.parent for p in scanned['plugins'].get(filename, [])
                  if valid_data(p.parent))
    if len(hits) == 1:
        return hits, None
    if len(hits) > 1:
        return [], 'ambiguous '+filename+' found in: ' + ' | '.join(map(str,hits))
    return [], ('required '+filename+' not found anywhere under '+str(scanned['root'])
                +'; verify archive was extracted, not just downloaded')

def preferred_folders(mod, scanned, parents):
    """Find user-selected option folders and their actual data roots.

    Fails closed on missing or ambiguous options. A selected container may hold
    one or more valid game-data subfolders, which are included, too.
    """
    choices = SELECTIONS.get(mod)
    if not choices: return None
    answer=[]
    for choice in choices:
        variants = [NORM(x) for x in choice['names']]
        candidates=[]
        for d in scanned['folders']:
            if not any(beneath(d, parent) for parent in parents): continue
            if NORM(d.name) in variants: candidates.append(d)
        candidates=unique(candidates)
        # Prefer shallowest matching folder (e.g. Core instead of nested Core).
        if candidates:
            depth=min(len(x.parts) for x in candidates)
            candidates=[x for x in candidates if len(x.parts)==depth]
        if len(candidates)!=1:
            return [], ('missing selected subfolder: ' if not candidates else 'ambiguous selected subfolder: ')+choice['names'][0]+ (' :: '+' | '.join(map(str,candidates)) if candidates else '')
        folder=candidates[0]
        # Include the selected folder AND nested folders with actual data; never
        # include unselected sibling variants.
        descendants=[d for d in scanned['folders'] if beneath(d,folder) and valid_data(d)]
        if not descendants: return [], 'selected subfolder has no game data: '+str(folder)
        answer.extend(sorted(descendants,key=lambda x:(len(x.parts),str(x).casefold())))
    return unique(answer), None

def unique_plugin_folders(mod, scanned, names):
    """Conservative fallback when the archive's extracted wrapper was renamed.

    Only run for simple, single-variant mods. An unambiguous physical filename
    can identify the directory even if the Nexus download folder is renamed.
    """
    hits=[]
    for name in names:
        found=unique(p.parent for p in scanned['plugins'].get(name.casefold(), []))
        if len(found)>1: return [], 'ambiguous plugin locations for '+name+': '+' | '.join(map(str,found))
        if found: hits.extend(found)
    hits=unique(hits)
    if not hits: return [], 'plugin file(s) not found'
    # Include game-data-bearing ancestor directories up to, but not including,
    # the selected installation root. This captures assets beside a plugin.
    result=[]
    for d in hits:
        lineage=[d,*list(d.parents)]
        for x in reversed(lineage):
            if x==scanned['root']: continue
            if beneath(x,scanned['root']) and valid_data(x):result.append(x)
    return unique(result), None

def select(entry, scanned, aliases, wanted_plugins, nexus_ids):
    mod = entry['for_mod']
    # These two mods have unique content filenames. Prefer exact file-based
    # detection over fragile mod/archive folder names, even if an alias matches.
    if mod in PROVINCE_FILES:
        return province_by_plugin(entry, scanned)
    exact=exact_mod_folders(mod,scanned)
    if exact is not None:
        if exact[1]:return exact
        if mod=='Concept Art Palace (Vivec City)':
            parents=roots_for(mod,scanned,aliases,nexus_ids)
            preferred=preferred_folders(mod,scanned,parents) if parents else None
            if preferred is not None:
                if preferred[1]:return preferred
                return unique(preferred[0]+exact[0]),None
        return exact
    explicit = explicit_data_folders(mod, scanned)
    if explicit is not None:
        return explicit
    asset=asset_mod_folders(mod,scanned)
    if asset is not None:return asset
    parents = roots_for(mod, scanned, aliases, nexus_ids)
    if not parents:
        if mod in AUTO_BY_PLUGIN:
            return unique_plugin_folders(mod, scanned, wanted_plugins.get(mod, []))
        return [], 'root not found'
    preferred=preferred_folders(mod,scanned,parents)
    if preferred is not None: return preferred
    extras = entry.get('extra_dirs') or []
    if extras:
        found = []
        for extra in extras:
            segments = tuple(NORM(x) for x in re.split(r'[\\/]+', extra) if x)
            matches=[]
            for d in scanned['folders']:
                for parent in parents:
                    if not beneath(d, parent):
                        continue
                    rel = tuple(NORM(x) for x in d.relative_to(parent).parts)
                    if segments and len(rel) >= len(segments) and rel[-len(segments):] == segments and valid_data(d):
                        matches.append(d)
                        break
            if len(matches)!=1:
                return [], ('no directory for '+extra if not matches else 'ambiguous directory for '+extra+': '+' | '.join(map(str,matches)))
            found.extend(matches)
        return unique(found), None
    # With no explicit path, first identify the folders containing this mod's requested plugins.
    plugin_dirs=[]
    for name in wanted_plugins.get(mod, []):
        for hit in scanned['plugins'].get(name, []):
            if any(beneath(hit,parent) for parent in parents): plugin_dirs.append(hit.parent)
    plugin_dirs = unique(plugin_dirs)
    if plugin_dirs:
        # Include any game-data-bearing parent (assets in a wrapper directory)
        # before the plugin directory, without traversing sibling options.
        additional=[]
        for d in plugin_dirs:
            for parent in parents:
                if beneath(d,parent):
                    x=d
                    while beneath(x,parent):
                        if valid_data(x):additional.append(x)
                        if x==parent:break
                        x=x.parent
        plugin_dirs=unique(additional+plugin_dirs)
        # Multiple plugin-bearing directories can be valid; refuse duplicate variants.
        for name in wanted_plugins.get(mod, []):
            hits=unique(x.parent for x in scanned['plugins'].get(name,[]) if any(beneath(x,parent) for parent in parents))
            if len(hits)>1: return [], 'ambiguous plugin variant: '+name
        return plugin_dirs, None
    # Asset-only: accept a unique leaf data root, not arbitrary packaging wrappers.
    ddirs = [x for x in scanned['folders'] if any(beneath(x,parent) for parent in parents) and valid_data(x)]
    leaves = [x for x in ddirs if not any(x!=y and beneath(y,x) for y in ddirs)]
    leaves = unique(leaves)
    if len(leaves)==1: return leaves, None
    return [], 'no data directory' if not leaves else 'ambiguous asset data dirs: '+' | '.join(map(str,leaves))

def read_lines(p): return p.read_text(encoding='utf-8-sig',errors='replace').splitlines()

def render_cfg(original, directories, contents, fallback):
    keep = [x for x in original if not re.match(r'^\s*(?:data|content)\s*=',x,re.I)]
    # Rebuild fallback archives only when there is an additional, verified archive.
    known={m.group(1).strip().casefold() for x in keep if (m:=re.match(r'^\s*fallback-archive\s*=\s*(.+?)\s*$',x,re.I))}
    for archive in fallback:
        if archive.casefold() not in known:
            keep.append('fallback-archive='+archive)
            known.add(archive.casefold())
    return '\n'.join(keep+[f'data="{str(d)}"' for d in directories]+[f'content={n}' for n in contents])+'\n'

def render_settings(old, entries):
    """Merge OpenMW settings by section/key while preserving unrelated settings."""
    lines=list(old)
    # Last requested value for a duplicate key wins, exactly like other settings.
    merged=collections.OrderedDict()
    for section,key,value in entries:
        merged[(section.casefold(),key.casefold())]=(section,key,value)
    for sec,key,value in merged.values():
        sections=[]
        for i,line in enumerate(lines):
            match=re.match(r'^\s*\[([^\]]+)\]\s*$',line)
            if match: sections.append((i,match.group(1)))
        found=next((j for j,(i,name) in enumerate(sections) if name.casefold()==sec.casefold()),None)
        if found is None:
            if lines and lines[-1].strip(): lines.append('')
            lines.extend([f'[{sec}]',f'{key} = {value}'])
            continue
        start=sections[found][0]
        end=sections[found+1][0] if found+1<len(sections) else len(lines)
        hits=[]
        for i in range(start+1,end):
            match=re.match(r'^\s*([^#;=]+?)\s*=\s*.*$',lines[i])
            if match and match.group(1).strip().casefold()==key.casefold(): hits.append(i)
        if hits:
            lines[hits[0]]=f'{key} = {value}'
            for i in reversed(hits[1:]): lines.pop(i)
        else: lines.insert(end,f'{key} = {value}')
    return '\n'.join(lines).rstrip()+'\n'

def master_names(plugin):
    """Read the header of a TES3 ESM/ESP/OMWADDON without third-party packages."""
    if plugin.suffix.casefold()=='.omwscripts': return []
    try:
        with plugin.open('rb') as f:
            header=f.read(16)
            if len(header)<16 or header[:4]!=b'TES3': return None
            size=int.from_bytes(header[4:8],'little')
            if size>16*1024*1024: return None
            block=f.read(size)
        names=[]; pos=0
        while pos+8<=len(block):
            name=block[pos:pos+4]; length=int.from_bytes(block[pos+4:pos+8],'little');pos+=8
            if length>len(block)-pos: break
            if name==b'MAST': names.append(block[pos:pos+length].split(b'\0')[0].decode('cp1252',errors='replace'))
            pos+=length
        return names
    except (OSError,PermissionError): return None

def main():
    parser=argparse.ArgumentParser(description='Combine DC and custom mods by Authentic Morrowind data-path/plugin order')
    parser.add_argument('--dc',help='I Heart Vanilla Director\'s Cut mod folder')
    parser.add_argument('--custom',help='Authentic Morrowind mod folder')
    parser.add_argument('--cfg',help='OpenMW openmw.cfg')
    parser.add_argument('--settings',help='OpenMW settings.cfg')
    parser.add_argument('--include-tr-factions',action='store_true',help='Opt in to adding TR_Factions.esp and its folder immediately after TR Mainland (extra to YAML)')
    parser.add_argument('--apply',action='store_true',help='Request applying; still prompts for APPLY')
    parser.add_argument('--allow-incomplete',action='store_true',help='Allow a TEST apply despite missing/ambiguous mods or masters; requires --apply and explicit confirmation')
    args=parser.parse_args()
    print('AUTHENTIC MORROWIND: DC FOUNDATION + CUSTOM OVERRIDES')
    # Fail closed if the bundled YAML is no longer identical to the source manifest.
    for fname, field in [('data-path-order.yml','data_paths'),('plugin-order.yml','plugins')]:
        expected=SOURCE_SHA256[fname]
        source=HERE/fname
        if not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest()!=expected:
            sys.exit('ERROR: '+fname+' differs from bundled source. Rebuild the manifest before applying. No changes made.')
    print('Preview is default. No mod files will be modified.')
    home=Path.home()
    cfg=Path(args.cfg or ask('Full path to openmw.cfg',str(home/'Documents'/'My Games'/'OpenMW'/'openmw.cfg'))).expanduser().resolve()
    if not cfg.is_file(): sys.exit('ERROR: openmw.cfg not found. No changes made.')
    settings=Path(args.settings or ask('Full path to settings.cfg',str(cfg.with_name('settings.cfg')))).expanduser().resolve()
    if not settings.is_file(): sys.exit('ERROR: settings.cfg not found. No changes made.')
    dc=Path(args.dc or ask('I Heart Vanilla DC mods folder')).expanduser().resolve()
    custom=Path(args.custom or ask('Authentic Morrowind CUSTOM mods folder')).expanduser().resolve()
    if not dc.is_dir() or not custom.is_dir() or canonical(dc)==canonical(custom):
        sys.exit('ERROR: supply two separate, existing mod directories. No changes made.')
    cfg_lines=read_lines(cfg); settings_lines=read_lines(settings)
    existing=[]
    for line in cfg_lines:
        m=re.match(r'^\s*data\s*=\s*(.*?)\s*$',line,re.I)
        if m:
            p=Path(os.path.expandvars(m.group(1).strip().strip('"')))
            if p.is_dir(): existing.append(p.resolve())
    game=next((p for p in existing if any(f.name.casefold()=='morrowind.esm' for f in datafiles(p))),None)
    if not game:
        game=Path(ask('Morrowind original Data Files folder')).expanduser().resolve()
    if not any(f.name.casefold()=='morrowind.esm' for f in datafiles(game)):
        sys.exit('ERROR: original Morrowind.esm not found. No changes made.')
    print('Scanning Director\'s Cut mods ...')
    base=scan(dc)
    print('Scanning custom mods ...')
    overlay=scan(custom)
    aliases=modnames(); nexus_ids=nexus_lookup(); wanted=collections.defaultdict(list)
    for p in MAN['plugins']:
        if p['file_name'].casefold() not in EXCLUDE_PLUGINS: wanted[p['for_mod']].append(actual_name(p['file_name']).casefold())
    selected=[]; missed=[]; ambiguous=[]; overrides=[]; active_mods=set()
    cache={}
    for idx,entry in enumerate(MAN['data_paths']):
        mod=entry['for_mod']
        if mod=='Morrowind':
            selected.append((idx,'game',entry,game)); active_mods.add(mod); continue
        # Each logical manifest entry: DC first, then custom. Custom overrides DC.
        found={}; errors={}
        for label,source in [('dc',base),('custom',overlay)]:
            key=(label,mod,tuple(entry.get('extra_dirs') or []))
            if key not in cache: cache[key]=select(entry,source,aliases,wanted,nexus_ids)
            dirs,err=cache[key]
            if dirs: found[label]=dirs
            elif err: errors[label]=err
        if not found:
            reason='; '.join(f'{k}: {v}' for k,v in errors.items())
            if 'ambiguous' in reason: ambiguous.append((idx,mod,entry.get('extra_dirs'),reason))
            else: missed.append((idx,mod,entry.get('extra_dirs'),reason))
            continue
        active_mods.add(mod)
        for label in ('dc','custom'):
            for p in found.get(label,[]): selected.append((idx,label,entry,p))
        if 'dc' in found and 'custom' in found:
            overrides.append((mod,entry.get('extra_dirs'),found['dc'],found['custom']))
    # Preserve YAML order EXACTLY, including repeated entries. Do not move a
    # directory to its last appearance: that changes the user's desired order.
    final=list(selected)
    optional_faction=[]
    if args.include_tr_factions:
        for label,source in [('dc',base),('custom',overlay)]:
            matches=unique(hit.parent for hit in source['plugins'].get('tr_factions.esp',[]) if valid_data(hit.parent))
            if len(matches)>1:
                ambiguous.append((-1,'TR Faction Integration',None,label+': multiple TR_Factions.esp folders: '+' | '.join(map(str,matches))))
            elif matches: optional_faction.append((label,matches[0]))
        if optional_faction:
            # Insert immediately after the last Tamriel Rebuilt occurrence.
            at=next((i+1 for i,(_,_,e,_) in reversed(list(enumerate(final))) if e['for_mod']=='Tamriel Rebuilt'),None)
            if at is not None:
                for label,folder in optional_faction:
                    final.insert(at,(-1,label,{'for_mod':'TR Faction Integration (optional)'},folder))
                    at+=1
    # All regular entries remain in the same sequence as the supplied YAML.
    original_indices=[idx for idx,_,_,_ in final if idx>=0]
    if original_indices!=sorted(original_indices):
        sys.exit('INTERNAL ERROR: data-path order was changed; no changes made.')
    dirs=[x[3] for x in final]
    byfilename=collections.defaultdict(list)
    for order,(_,label,entry,folder) in enumerate(final):
        for p in datafiles(folder):
            if p.suffix.casefold() in PLUG_EXT:
                byfilename[p.name.casefold()].append((order,p,label))
    content=[]; missing_plugins=[]; plugin_sources={}; duplicates=[]
    for item in MAN['plugins']:
        original_name=item['file_name']
        if original_name.casefold() in EXCLUDE_PLUGINS: continue
        name=actual_name(original_name)
        hits=byfilename.get(name.casefold(),[])
        if not hits:
            missing_plugins.append((item['for_mod'],name)); continue
        # Later active data path wins exactly as OpenMW's VFS resolves the filename.
        chosen=hits[-1]
        if name.casefold() not in {x.casefold() for x in content}:
            content.append(name)
            plugin_sources[name.casefold()]=chosen[1]
        if len(hits)>1: duplicates.append((name,hits))
    # Optional plugin is never inserted unless the user explicitly requests it.
    if args.include_tr_factions and optional_faction:
        faction_hits=byfilename.get('tr_factions.esp',[])
        if faction_hits and not any(x.casefold()=='tr_factions.esp' for x in content):
            at=next((i+1 for i,n in enumerate(content) if n.casefold()=='tr_mainland.esm'),len(content))
            content.insert(at,'TR_Factions.esp')
            plugin_sources['tr_factions.esp']=faction_hits[-1][1]
    # Master checking: engines load content in manifest order.
    index={x.casefold():i for i,x in enumerate(content)}
    missing_masters=[]; wrong_order=[]; unreadable=[]
    for pos,name in enumerate(content):
        p=plugin_sources[name.casefold()]; masters=master_names(p)
        if masters is None:
            unreadable.append((name,str(p))); continue
        for master in masters:
            masterpos=index.get(master.casefold())
            if masterpos is None: missing_masters.append((name,master))
            elif masterpos>=pos: wrong_order.append((name,master))
    fallback=[]; settings_to_apply=[]; warnings=[]
    seen_cfg_archives={m.group(1).strip().casefold() for line in cfg_lines if (m:=re.match(r'^\s*fallback-archive\s*=\s*(.+?)\s*$',line,re.I))}
    accessible_archives={x.name.casefold() for d in dirs for x in datafiles(d) if x.suffix.casefold()=='.bsa'}
    for e in EXTRA:
        if any(m not in active_mods for m in e.get('for_mods',[])): continue
        if e.get('in_settings'):
            section=None
            for raw in e['text'].splitlines():
                line=raw.strip()
                if not line or line.startswith(('#',';')):continue
                if line.startswith('[') and line.endswith(']'):
                    section=line[1:-1].strip();continue
                if '=' in line and section:
                    key,val=line.split('=',1)
                    settings_to_apply.append((section,key.strip(),val.strip()))
        else:
            for line in e['text'].splitlines():
                m=re.match(r'^\s*fallback-archive\s*=\s*(.+?)\s*$',line,re.I)
                if m:
                    archive=m.group(1).strip()
                    if archive.casefold() in accessible_archives: fallback.append(archive)
                    elif archive.casefold() not in seen_cfg_archives:
                        warnings.append('Referenced BSA not found in active data paths: '+archive)
    output_cfg=render_cfg(cfg_lines,dirs,content,fallback)
    output_settings=render_settings(settings_lines,settings_to_apply)
    report=[
        'AUTHENTIC MORROWIND PREVIEW REPORT','='*75,
        'DC root: '+str(dc),'Custom root: '+str(custom),'Game folder: '+str(game),
        'OpenMW config: '+str(cfg),'OpenMW settings: '+str(settings),
        f'Active data entries (including intentional repeats and DC/custom overlays): {len(dirs)} / {len(MAN["data_paths"])} desired YAML entries',
        'YAML ORDER: PRESERVED (optional TR Faction Integration: '+('ON' if args.include_tr_factions else 'OFF')+')',
        f'Enabled plugins: {len(content)} / {len(MAN["plugins"])-len(EXCLUDE_PLUGINS)} desired entries (excluded by user: {len(EXCLUDE_PLUGINS)})',
        f'Missing data entries: {len(missed)}',f'Ambiguous data entries: {len(ambiguous)}',
        f'Missing plugins: {len(missing_plugins)}',f'Missing plugin masters: {len(missing_masters)}',
        f'Invalid master order: {len(wrong_order)}',f'Unreadable plugin headers: {len(unreadable)}',
        f'Plugins present in more than one active data directory (last takes precedence): {len(duplicates)}',
        f'Logical entries with both DC and custom versions (custom comes second): {len(overrides)}',
        '', 'USER-EXCLUDED MANIFEST PLUGINS:', *sorted(EXCLUDE_PLUGINS), '', 'MISSING DATA ENTRIES:']
    report += [f'{i+1}: {m} / {ex or "<root>"} :: {why}' for i,m,ex,why in missed]
    report += ['','AMBIGUOUS DATA ENTRIES:']+[f'{i+1}: {m} / {ex or "<root>"} :: {why}' for i,m,ex,why in ambiguous]
    report += ['','MISSING PLUGINS:']+[f'{mod}: {p}' for mod,p in missing_plugins]
    report += ['','MISSING MASTERS:']+[f'{p} REQUIRES {m}' for p,m in missing_masters]
    report += ['','INVALID MASTER ORDER:']+[f'{p} MUST FOLLOW {m}' for p,m in wrong_order]
    report += ['','UNREADABLE HEADERS:']+[f'{p}: {f}' for p,f in unreadable]
    report += ['','DUPLICATE PLUGINS (winning file is last):']
    report += [f'{name}: '+' | '.join(f'[{label}] {p}' for _,p,label in hits)+' -> WINNER '+str(hits[-1][1]) for name,hits in duplicates]
    report += ['','BOTH DC AND CUSTOM AVAILABLE:']
    report += [f'{m} / {ex or "<root>"}: DC {";".join(map(str,b))} -> CUSTOM {";".join(map(str,c))}' for m,ex,b,c in overrides]
    if not args.include_tr_factions:
        warnings.append('TR_Factions.esp is NOT in plugin-order.yml or data-path-order.yml. For optional integration use --include-tr-factions (adds an extra entry after TR Mainland).')
    elif not optional_faction:
        warnings.append('Optional TR_Factions.esp requested but was not found in either mod root.')
    shader_source,shader_target,shader_error=shader_plan(overlay)
    report += ['', 'RAFAEL SHADERS (resource-copy; separate OpenMW data= entry is also configured):',
               ('NOT READY: '+shader_error if shader_error else f'READY: {shader_source} -> {shader_target} ({len([f for f in shader_source.rglob("*") if f.is_file()])} files)')]
    report += ['','WARNINGS:']+warnings
    report += ['','EXISTING OPENMW DATA DIRECTORIES NOT INCLUDED IN GENERATED ORDER:']
    selected_keys={canonical(d) for d in dirs}
    report += [str(d) for d in existing if canonical(d) not in selected_keys] or ['(none)']
    report += ['','FINAL DATA PATH ORDER (last overrides earlier):']+[f'{i+1:03d}. [{label}] {folder}  ({entry["for_mod"]})' for i,(_,label,entry,folder) in enumerate(final)]
    report += ['','FINAL PLUGIN LOAD ORDER:']+[f'{i+1:03d}. {name}  <- {plugin_sources[name.casefold()]}' for i,name in enumerate(content)]
    outdir=HERE/'preview';outdir.mkdir(exist_ok=True)
    (outdir/'openmw-authentic-PREVIEW.cfg').write_text(output_cfg,encoding='utf-8')
    (outdir/'settings-authentic-PREVIEW.cfg').write_text(output_settings,encoding='utf-8')
    (outdir/'authentic-report.txt').write_text('\n'.join(report)+'\n',encoding='utf-8')
    print('\n'.join(report[0:16]))
    print('\nPreview output folder:',outdir)
    blockers=len(missed)+len(ambiguous)+len(missing_plugins)+len(missing_masters)+len(wrong_order)+len(unreadable)
    if shader_error:
        print('NOTE: Rafael shaders not installed: '+shader_error)
    if blockers and not (args.apply and args.allow_incomplete):
        print(f'BLOCKED: {blockers} issues. Nothing applied. Inspect authentic-report.txt.')
        print('To apply the available mods, run INSTALL_AUTHENTIC_MORROWIND_PARTIAL.bat.')
        return 2
    if not args.apply:
        print('PREVIEW ONLY. Re-run with --apply after reviewing the report.')
        return 0
    if blockers:
        print('\n'+'!'*72)
        print('INCOMPLETE TEST MODE: This is NOT a playable or valid mod configuration.')
        print(f'{blockers} unresolved issues; missing masters may prevent startup.')
        print('Only the found portion of your YAML lists will be installed into OpenMW CFG.')
        print('Your current active OpenMW config will be replaced; backups are made.')
        print('!'*72)
        confirmation='APPLY INCOMPLETE TEST'
    else:
        print('No missing entries, masters or ambiguous paths detected.')
        confirmation='APPLY'
    if ask(f'Type {confirmation} to replace your OpenMW configuration (not mod files)')!=confirmation:
        print('Cancelled; original configs untouched.');return 0
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    targets=((cfg,output_cfg),(settings,output_settings))
    backups=[]
    try:
        for dest,_ in targets:
            backup=dest.with_name(dest.name+'.backup-authentic-'+stamp)
            shutil.copy2(dest,backup)
            backups.append((dest,backup))
        for dest,body in targets:
            tmp=dest.with_name(dest.name+'.tmp-authentic')
            try:
                tmp.write_text(body,encoding='utf-8')
                os.replace(tmp,dest)
            finally:
                if tmp.exists(): tmp.unlink()
        for dest,backup in backups: print('Updated',dest,'Backup',backup)
    except Exception:
        for dest,backup in backups:
            try: shutil.copy2(backup,dest)
            except OSError: print('URGENT: Could not restore',dest,'from',backup)
        raise
    if shader_source is not None:
        try:install_shaders(shader_source,shader_target)
        except Exception as exc:print('WARNING: Shader copy failed; OpenMW configuration was applied: '+repr(exc))
    print('Finished. Run OpenMW Launcher and validate load order before playing.')
    return 0

if __name__=='__main__':
    try: sys.exit(main())
    except (KeyboardInterrupt,EOFError): sys.exit('\nCancelled; no changes applied unless explicitly confirmed.')
    except Exception as exc: sys.exit('ERROR: '+repr(exc))
