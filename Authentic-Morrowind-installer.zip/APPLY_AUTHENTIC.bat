@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 apply_authentic.py %*
) else (
    python apply_authentic.py %*
)
echo.
echo Finished. Inspect the preview folder and report before applying.
pause
